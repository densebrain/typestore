import Bluebird = require('bluebird')
declare var Promise:Bluebird<any>

// declare interface Promise<R> {
//
// }
///<reference path="../node_modules/aws-sdk-typescript/output/typings/aws-dynamodb"/>
///<reference path="../node_modules/aws-sdk-typescript/output/typings/aws-sdk"/>

// declare module NodeJS {
// 	import Bluebird = require('bluebird')
//
// 	interface Global {
// 		Promise:Bluebird<any>
// 	}
// }

