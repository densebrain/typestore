
export const ReturnTypeKey = 'design:returntype'
export const TypeKey = 'design:type'

export const TypeStoreModelKey = 'dyno:model'
export const TypeStoreAttrKey = 'dyno:attr'
export const TypeStoreRepoKey = 'dyno:repo'
export const TypeStoreFinderKey = 'dyno:finder'
export const TypeStoreFindersKey = 'dyno:finders'

