

export const DynamoDBLocalEndpoint = 'http://localhost:8000'
export const test = '1234'
