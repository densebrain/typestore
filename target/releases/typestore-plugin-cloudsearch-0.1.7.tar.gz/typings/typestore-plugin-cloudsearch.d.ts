/// <reference path="../../../typings/browser.d.ts"/>
/// <reference path="../../../node_modules/aws-sdk-typescript/output/typings/aws-cloudsearchdomain.d.ts"/>
/// <reference path="../../../node_modules/aws-sdk-typescript/output/typings/aws-sdk.d.ts"/>

