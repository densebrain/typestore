
export const DynamoDBFinderKey = 'dynamodb:finder'
export const DynamoDBLocalEndpoint = 'http://localhost:8000'
export const test = '1234'

