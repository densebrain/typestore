
export {msg,Strings} from 'typestore'

export const DynamoStrings = {
	TableDeleting: 'Table is DELETING ?0'
}

