TypeStore DynamoDB Plugin
---

DynamoDB backing store provider for TypeStore
persistence framework

For examples and docs, checkout typestore core documentation
@ https://github.com/densebrain/typestore