///<reference path="../typings/typestore-mocks"/>
export * from './MockStore'

