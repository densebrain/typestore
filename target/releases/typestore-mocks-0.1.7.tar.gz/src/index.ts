///<reference path="../typings/typestore-mocks"/>
import 'reflect-metadata'

export * from './MockStore'

import * as Fixtures from './fixtures/SimpleModels'
export {
	Fixtures
}

