TypeStore Mocks
---

Mocks used for testing new plugins for TypeStore

For examples and docs, checkout typestore core documentation
@ https://github.com/densebrain/typestore