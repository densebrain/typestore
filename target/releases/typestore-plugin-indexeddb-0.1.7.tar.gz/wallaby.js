


module.exports = function (wallaby) {
	var config = require('../../etc/wallaby/wallaby.base')(wallaby)

	return Object.assign(config,{
		// Extended options go here
	});
};
