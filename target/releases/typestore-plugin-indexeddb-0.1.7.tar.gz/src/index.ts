/// <reference path="../typings/typestore-plugin-localstorage.d.ts"/>

export * from './IndexedDBDecorations'
export * from './IndexedDBPlugin'