import * as Decorations from './DynamoDBDecorations'
import {DynamoDBStore as Store} from './DynamoDBStore'


export {
	Decorations,
	Store
}

