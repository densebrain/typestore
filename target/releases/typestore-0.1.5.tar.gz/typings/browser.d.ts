/// <reference path="./reflect-metadata.d.ts" />
/// <reference path="browser/ambient/expectations/index.d.ts" />
/// <reference path="browser/ambient/mocha/index.d.ts" />
/// <reference path="browser/ambient/node/index.d.ts" />
/// <reference path="browser/definitions/bluebird/index.d.ts" />
/// <reference path="browser/definitions/chalk/index.d.ts" />
/// <reference path="browser/definitions/node-uuid/index.d.ts" />
