export {}

declare global {
	var getLogger:Function
}