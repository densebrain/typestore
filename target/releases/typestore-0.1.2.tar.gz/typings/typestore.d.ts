import Bluebird = require('bluebird')
declare var Promise:Bluebird<any>

interface Bluebird<R> {

}
