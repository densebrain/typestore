TypeStore CloudSearch Plugin
---

Adds an external indexing option for any TypeStore
Store provider, simply put - no matter what
persistence store you use, you can tack on
CloudSearch with ease.

For examples and docs, checkout typestore core documentation
@ https://github.com/densebrain/typestore